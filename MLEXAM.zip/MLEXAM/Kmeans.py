import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
def euclidean_distance(a,b):
    return np.sqrt(np.sum((a-b)**2))
class KMeans:
    def __init__(self,k=3,max_iters = 100):
        self.k = k
        self.max_iters = max_iters
    def fit(self,X):
        centroids = X[np.random.choice(X.shape[0],self.k,replace = False)]
        for _ in range(self.max_iters):
            distances =np.array([[euclidean_distance(x,c) for c in centroids] for x in X])
            labels = np.argmin(distances,axis = 1)
            new_centroids =np.array([X[labels == i].mean(axis = 0) for i in range(self.k)])
            if np.all(centroids == new_centroids): break
            centroids = new_centroids
        self.centroids = centroids
        self.labels = labels
    def predict(self,X):
        distances = np.array([euclidean_distance(x,c) for c in self.centroids] for x in X)
        return np.argmin(distances,axis = 1)
def load_data(file_path):
    return pd.read_csv(file_path).values
if __name__ == "__main__":
    X = load_data('kmeans_data.csv')
    kmeans = KMeans(k=3)
    kmeans.fit(X)
    print("Centroids:",kmeans.centroids)
    if X.shape[1] == 2:
        plt.scatter(X[:,0],X[:,1],c=kmeans.labels,cmap = 'viridis')
        plt.scatter(kmeans.centroids[:,0],kmeans.centroids[:,1],color='red',marker = 'X',s=200)
        plt.title("K-Means Clustering")
        plt.show()