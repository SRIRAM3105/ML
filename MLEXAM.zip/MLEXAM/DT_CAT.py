import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier
from sklearn import tree
from sklearn.metrics import accuracy_score, confusion_matrix
from sklearn.preprocessing import LabelEncoder
import seaborn as sns


data = pd.read_csv('DT1data.csv')


data = pd.get_dummies(data, columns=['Age', 'Income', 'Gender', 'Education']) 


label_encoder = LabelEncoder()
data['Default'] = label_encoder.fit_transform(data['Default'])  # Convert 'Yes'/'No' to 1/0

# Visualize the distribution of the target variable
sns.countplot(x='Default', data=data)
plt.show()

# Define features (X) and target (Y)
X = data.drop('Default', axis=1)  # All columns except the target 'Default'
Y = data['Default']  # The target column

# Split data into training and testing sets
X_train, X_test, Y_train, Y_test = train_test_split(X, Y, test_size=0.3, random_state=100)

# Train the Decision Tree Classifier with class weights to handle imbalance
model = DecisionTreeClassifier(criterion='entropy', random_state=100, max_depth=5, min_samples_leaf=5, class_weight='balanced')
model.fit(X_train, Y_train)

# Make predictions
Y_pred = model.predict(X_train)

# Calculate accuracy
print("Predictions:", Y_pred)
print("Accuracy:", accuracy_score(Y_train, Y_pred) * 100)

# Confusion Matrix
cm = confusion_matrix(Y_train, Y_pred)

# Print the confusion matrix
print("Confusion Matrix:")
print(cm)

# Plot the decision tree
plt.figure(figsize=(10, 8))
tree.plot_tree(model, feature_names=X.columns, class_names=['No Repay', 'Repay'], filled=True, rounded=True, fontsize=10)
plt.show()
