import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
class LinearRegression:
    def __init__(self,learning_rate = 0.01,n_iters = 1000):
        self.learning_rate = learning_rate
        self.n_iters = n_iters
        self.weights = None
        self.bias = None
    def fit(self,X,Y):
        n_samples,n_features = X.shape
        self.weights = np.zeros(n_features)
        self.bias = 0
        for _ in range(self.n_iters):
            y_pred = np.dot(X,self.weights) + self.bias
            dw = (1/n_samples) * np.dot(X.T,(y_pred - Y) )
            db = (1/n_samples) * np.sum(y_pred - Y)
            self.weights-=self.learning_rate*dw
            self.bias-=self.learning_rate*db
    def predict(self,X):
        return np.dot(X,self.weights) + self.bias
    def r_squared(self,y_true,y_pred):
        return 1 - np.sum((Y - y_pred) **2)/np.sum((Y - np.mean(Y)) **2)
data = pd.read_csv('test.csv')
X = data.values[:,:-1]
Y = data.values[:,-1]
model = LinearRegression(learning_rate = 0.01,n_iters = 1000)
model.fit(X,Y)
predictions = model.predict(X)
print("Predictions:",predictions)
mse = np.mean((Y - predictions) **2)
print("MSE:",mse)
r2 = model.r_squared(Y,predictions)
print("R-squared:",r2)
plt.figure(figsize = (8,6))
plt.scatter(Y,predictions,color='blue',label='Actual vs predicted')
plt.plot([min(Y),max(Y)],[min(Y),max(Y)],color='red',linestyle='--',label='Regression Line')
plt.legend()
plt.show()
y = model.predict(11)

print("11th week:",y[0])

            