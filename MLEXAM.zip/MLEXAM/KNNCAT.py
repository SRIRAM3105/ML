import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.metrics import confusion_matrix
import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap
from collections import Counter

# Custom colormap
cmap = ListedColormap(['#FF0000', '#00FF00'])

# Function to calculate Euclidean distance
def euclidean_distance(x1, x2):
    return np.sqrt(np.sum((x1 - x2) ** 2))

# KNN Classifier
class KNN:
    def __init__(self, k=3):
        self.k = k
    
    def fit(self, X, y):
        self.X_train = X
        self.y_train = y
    
    def predict(self, X):
        predictions = [self._predict(x) for x in X]
        return np.array(predictions)
    
    def _predict(self, x):
        distances = [euclidean_distance(x, x_train) for x_train in self.X_train]
        k_indices = np.argsort(distances)[:self.k]
        k_nearest_labels = [self.y_train[i] for i in k_indices]
        most_common = Counter(k_nearest_labels).most_common(1)
        return most_common[0][0]

# Load and preprocess the data
data = pd.read_csv('bank.csv', delimiter=';')

# Convert target variable to binary format
data['y'] = data['y'].str.strip()
y = data['y'].map({'no': 0, 'yes': 1}).values

# Convert categorical features to numerical using one-hot encoding
X = pd.get_dummies(data[['age', 'job', 'marital', 'education', 'default', 'balance', 'housing', 
                         'loan', 'contact', 'day', 'month', 'duration', 'campaign', 
                         'pdays', 'previous', 'poutcome']])

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=1234)

# Plot the data
plt.figure()
plt.scatter(X['age'], X['balance'], c=y, cmap=cmap, edgecolor='k', s=20)
plt.xlabel("Age")
plt.ylabel("Balance")
plt.title("Age vs Balance by Class")
plt.show()

# Initialize and fit KNN model
knn = KNN(k=3)
knn.fit(X_train.values, y_train)
predictions = knn.predict(X_test.values)

# Calculate accuracy
accuracy = np.mean(predictions == y_test) * 100
print(f"Accuracy: {accuracy:.2f}%")

#testing
test_data = pd.DataFrame([[35, "student", "single", "secondary", "no", 1000, "yes", "no", "cellular", 
                           15, "jul", 120, 2, -1, 0, "unknown"]],
                         columns=['age', 'job', 'marital', 'education', 'default', 'balance', 'housing', 
                                  'loan', 'contact', 'day', 'month', 'duration', 'campaign', 
                                  'pdays', 'previous', 'poutcome'])

test_data_encoded = pd.get_dummies(test_data)
test_data_encoded = test_data_encoded.reindex(columns=pd.get_dummies(data[['age', 'job', 'marital', 
                                                                           'education', 'default', 
                                                                           'balance', 'housing', 
                                                                           'loan', 'contact', 'day', 
                                                                           'month', 'duration', 
                                                                           'campaign', 'pdays', 
                                                                           'previous', 'poutcome']]).columns, 
                                              fill_value=0)

# Convert to NumPy array and predict
test_prediction = knn.predict(test_data_encoded.values)
print(test_prediction[0])
# Confusion Matrix
cm = confusion_matrix(y_test, predictions)
print("Confusion Matrix:")
print(cm)
