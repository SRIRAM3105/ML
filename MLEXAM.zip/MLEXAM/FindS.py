import numpy as np
import pandas as pd
data = pd.read_csv('data.csv')
concepts = data.values[:,:-1]
target = data.values[:,-1]
def learn(concepts,target):
    specific_h = None
    for i,val in enumerate(target):
        if val == 'yes':
            specific_h = concepts[i].copy()
            break
    for i,h in enumerate(concepts):
        if target[i] == 'yes':
            for x in range(len(specific_h)):
                if h[x] != specific_h[x]:
                    specific_h[x] = '?'
    return specific_h
print(learn(concepts,target))