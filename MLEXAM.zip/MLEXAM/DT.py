import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier
from sklearn import tree
from sklearn.metrics import accuracy_score, confusion_matrix
data = pd.read_csv('DTdata.csv')
X = data.values[:, 0:4]
Y = data.values[:, 5]
X_train, X_test, Y_train, Y_test = train_test_split(X, Y, test_size=0.3, random_state=100)
model = DecisionTreeClassifier(criterion='entropy', random_state=100, max_depth=3, min_samples_leaf=5)
model.fit(X_train, Y_train)
Y_pred = model.predict(X_train)
print("Predictions:", Y_pred)
print("Accuracy:", accuracy_score(Y_train, Y_pred) * 100)
cm = confusion_matrix(Y_train, Y_pred)
print("Confusion Matrix:")
print(cm)
plt.figure(figsize=(10, 8))
tree.plot_tree(model, feature_names=data.columns[:4], class_names=['Yrepay', 'Nrepay'], filled=True, rounded=True, fontsize=10)
plt.show()
