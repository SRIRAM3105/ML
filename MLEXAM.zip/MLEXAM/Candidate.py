import numpy as np
import pandas as pd
data = pd.read_csv('data.csv')
concepts = data.values[:,:-1]
target = data.values[:,-1]
def learn(concepts,target):
    specific_h = concepts[0].copy()
    print("Initialisation of specific and general hypothesis")
    general_h = [["?" for _ in range(len(specific_h))] for _ in range(len(specific_h))]
    print("specific_h:",specific_h)
    print("general_h:",general_h)
    for i,h in enumerate(concepts):
        if target[i] == 'yes':
            for x in range(len(specific_h)):
                if h[x] != specific_h[x]:
                    specific_h[x] = '?'
                    general_h[x][x] = '?'
            print("Steps in CEA(",i+1,")")
            print(specific_h)
            print(general_h)
        if target[i] == 'no':
            for x in range(len(specific_h)):
                if h[x] != specific_h[x]:
                    general_h[x][x] = specific_h[x]
                else:
                    general_h[x][x] = '?'
            print("Steps in CEA(",i+1,")")
            print(specific_h)
            print(general_h)
    indices = [i for i,val in enumerate(general_h) if val == ["?"] * len(specific_h)]
    for i in indices:
        general_h.remove(["?"]*len(specific_h))
    return specific_h,general_h
s_final,g_final = learn(concepts,target)
print("Final specific:",s_final)
print("Final general:",g_final)
    
                
            