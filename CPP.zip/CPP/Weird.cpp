#include<iostream>
#include<vector>
using namespace std;
int main(){
    long long n; cin>>n;
    vector<long long>answer;
    answer.push_back(n);
    while(n!=1){
        if(n%2 == 0){
            n/=2;
            answer.push_back(n);
        }
        else{
            n=(n*3)+1;
            answer.push_back(n);
        }
    }
    for(int i=0;i<answer.size();i++){
        cout<<answer[i]<<" ";
    }
    cout<<endl;
}