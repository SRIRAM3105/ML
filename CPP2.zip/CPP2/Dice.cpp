#include<iostream>
#include<vector>
using namespace std;
const int MOD = 1e9 +7;
typedef long long ll;
int main(){
ll n; cin>>n;
vector<ll>dp(n+1);
dp[0] = dp[1] = 1;
for(ll i=2;i<=n;i++){
for(ll j=1;j<=6;j++){
    if(i-j >= 0){
        dp[i] = (dp[i] + dp[i-j]) % MOD ;
    }
}
}
cout<<dp[n]<<endl;
return 0;
}