public class BMI {
    private String name;
    private int age;
    private double weight; // Weight in pounds
    private double height; // Height in inches

    // Constructor with all fields
    public BMI(String name, int age, double weight, double height) {
        this.name = name;
        this.age = age;
        this.weight = weight;
        this.height = height;
    }

    // Constructor with default age of 20
    public BMI(String name, double weight, double height) {
        this(name, 20, weight, height);
    }

    // Method to calculate BMI
    public double getBMI() {
        return (weight / (height * height)) * 703;
    }

    // Method to determine BMI status
    public String getStatus() {
        double bmi = getBMI();
        if (bmi < 18.5) {
            return "Underweight";
        } else if (bmi < 25) {
            return "Normal";
        } else if (bmi < 30) {
            return "Overweight";
        } else {
            return "Obese";
        }
    }

    // Getter methods
    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }

    public double getWeight() {
        return weight;
    }

    public double getHeight() {
        return height;
    }

    public static void main(String[] args) {
        // Test program
        BMI bmi1 = new BMI("John Doe", 25, 150, 68); // Weight in pounds, height in inches
        System.out.println("Name: " + bmi1.getName());
        System.out.println("Age: " + bmi1.getAge());
        System.out.println("BMI: " + bmi1.getBMI());
        System.out.println("Status: " + bmi1.getStatus());

        BMI bmi2 = new BMI("Jane Smith", 120, 62); // Default age 20
        System.out.println("Name: " + bmi2.getName());
        System.out.println("Age: " + bmi2.getAge());
        System.out.println("BMI: " + bmi2.getBMI());
        System.out.println("Status: " + bmi2.getStatus());
    }
}
