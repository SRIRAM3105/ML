public class StopWatch {
    private long startTime;
    private long endTime;

    // No-arg constructor initializes startTime with the current time
    public StopWatch() {
        this.startTime = System.currentTimeMillis();
    }

    // Method to reset startTime to the current time
    public void start() {
        this.startTime = System.currentTimeMillis();
    }

    // Method to set endTime to the current time
    public void stop() {
        this.endTime = System.currentTimeMillis();
    }

    // Method to return the elapsed time in milliseconds
    public long getElapsedTime() {
        return endTime - startTime;
    }

    // Getter methods
    public long getStartTime() {
        return startTime;
    }

    public long getEndTime() {
        return endTime;
    }

    public static void main(String[] args) {
        // Test program: Measure execution time of sorting 100,000 numbers
        int[] numbers = new int[100000];
        // Generate 100,000 random numbers
        for (int i = 0; i < numbers.length; i++) {
            numbers[i] = (int) (Math.random() * 100000);
        }

        StopWatch stopWatch = new StopWatch();
        stopWatch.start(); // Start timing

        // Perform selection sort
        selectionSort(numbers);

        stopWatch.stop(); // Stop timing

        System.out.println("Elapsed time for sorting 100,000 numbers: " + stopWatch.getElapsedTime() + " milliseconds");
    }

    // Selection sort implementation
    public static void selectionSort(int[] array) {
        for (int i = 0; i < array.length - 1; i++) {
            // Find the minimum element in the unsorted part
            int minIndex = i;
            for (int j = i + 1; j < array.length; j++) {
                if (array[j] < array[minIndex]) {
                    minIndex = j;
                }
            }
            // Swap the found minimum element with the first element of the unsorted part
            int temp = array[minIndex];
            array[minIndex] = array[i];
            array[i] = temp;
        }
    }
}
