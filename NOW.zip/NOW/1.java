import java.util.Scanner;

class Location {
    public int row;
    public int column;
    public double maxValue;

    // Constructor
    public Location(int row, int column, double maxValue) {
        this.row = row;
        this.column = column;
        this.maxValue = maxValue;
    }
}

public class FindLargestElement {

    public static Location locateLargest(double[][] a) {
        int maxRow = 0, maxColumn = 0;
        double maxValue = a[0][0];

        // Iterate through the array to find the largest value and its location
        for (int i = 0; i < a.length; i++) {
            for (int j = 0; j < a[i].length; j++) {
                if (a[i][j] > maxValue) {
                    maxValue = a[i][j];
                    maxRow = i;
                    maxColumn = j;
                }
            }
        }

        return new Location(maxRow, maxColumn, maxValue);
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Input number of rows and columns
        System.out.print("Enter the number of rows and columns in the array: ");
        int rows = scanner.nextInt();
        int columns = scanner.nextInt();

        double[][] array = new double[rows][columns];

        // Input the array elements
        System.out.println("Enter the array:");
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < columns; j++) {
                array[i][j] = scanner.nextDouble();
            }
        }

        // Locate the largest element
        Location location = locateLargest(array);

        // Output the result
        System.out.println("The location of the largest element is " + location.maxValue +
                " at (" + location.row + ", " + location.column + ")");
    }
}
